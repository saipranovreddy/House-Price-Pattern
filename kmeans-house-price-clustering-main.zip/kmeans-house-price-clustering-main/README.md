# Klastering Harga Rumah dengan K-Means

Proyek ini merupakan analisis pengelompokan (clustering) harga rumah menggunakan algoritma **K-Means**. Dataset dianalisis untuk menemukan pola pengelompokan berdasarkan fitur harga dan lokasi (atau fitur relevan lainnya).

## 📊 Visualisasi Klaster

Visualisasi hasil klastering menggunakan scatter plot untuk memperlihatkan sebaran data berdasarkan hasil klaster K-Means:

![Visualisasi KMeans](kmeans_plot.png)

## 🛠️ Tools & Library
- Python
- scikit-learn
- matplotlib
- seaborn (jika digunakan)
- pandas


## ▶️ Cara Menjalankan
1. Buka file notebook di Google Colab atau Jupyter.
2. Jalankan seluruh sel.
3. Lihat hasil klaster dan visualisasi di bagian bawah notebook.

## 🎯 Tujuan
Mengeksplorasi metode klastering sebagai pendekatan analisis eksploratif dalam data harga rumah, untuk menemukan pola atau segmentasi pasar potensial.

---

Semoga bermanfaat!
